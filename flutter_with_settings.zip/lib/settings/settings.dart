class AppSettings {
  static const String appName = "4K Freelancer";
  static const String theme = "light"; // Options: light, dark
  static const bool notificationsEnabled = true;
}
